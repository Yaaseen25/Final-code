package com.example.gymbuddymessaging;

public class UserDetails {
    static String username = "";
    static String password = "";
    static String chatWith = "";
}
